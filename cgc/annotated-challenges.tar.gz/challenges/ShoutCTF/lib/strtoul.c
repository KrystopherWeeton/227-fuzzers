#define STRTOUL
#include "strtol.c"
